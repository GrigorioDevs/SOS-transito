import { useId, useState } from "react";
import "./LoginPage.css";

function Icon({ name, size = 18, ...props }) {
  const paths = {
    user: <><path d="M20 21a8 8 0 0 0-16 0" /><circle cx="12" cy="7" r="4" /></>,
    lock: <><rect x="5" y="10" width="14" height="11" rx="1.6" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /><path d="M12 14v3" /></>,
    eye: <><path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Z" /><circle cx="12" cy="12" r="2.8" /></>,
    eyeOff: <><path d="M3 3 21 21" /><path d="M10.6 6.1A11 11 0 0 1 12 6c6.4 0 10 6 10 6a15.7 15.7 0 0 1-4 4.2M6.1 6.2C3.4 8 2 12 2 12s3.6 6 10 6c1.2 0 2.3-.2 3.3-.5" /><path d="M10 10a3 3 0 0 0 4 4" /></>,
    arrow: <><path d="M4 12h16" /><path d="m14 6 6 6-6 6" /></>,
    replay: <><path d="M3 11a9 9 0 1 1 2.1 6" /><path d="M3 4v7h7" /></>,
    headlight: <><path d="M14 6c4 0 6 3 6 6s-2 6-6 6h-2V6h2Z" /><path d="M8 7H3m5 5H2m6 5H3" /></>,
    play: <path d="m8 5 11 7-11 7z" />,
    pause: <><path d="M9 5v14" /><path d="M15 5v14" /></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.55" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      {paths[name]}
    </svg>
  );
}

function CarHeadlights() {
  const id = useId();
  const glowId = `${id}-glow`;
  const beamId = `${id}-beam`;

  // Mesmas coordenadas do PNG (1644 × 957): a luz acompanha seu tamanho.
  return (
    <svg
      className="ignicao-headlights"
      viewBox="0 0 1644 957"
      preserveAspectRatio="none"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <filter id={glowId} x="-120%" y="-120%" width="340%" height="340%">
          <feGaussianBlur stdDeviation="11" />
        </filter>
        <linearGradient
          id={beamId}
          x1="900" y1="465" x2="1590" y2="900"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#ffe6a0" stopOpacity=".21" />
          <stop offset="1" stopColor="#ffe6a0" stopOpacity="0" />
        </linearGradient>
      </defs>

      <path d="M829 450L1644 730V957L1500 957Z" fill={`url(#${beamId})`} />

      {/* Halo suave em volta das duas lâmpadas. */}
      <ellipse cx="829" cy="450" rx="34" ry="28" fill="#ffe7a5" filter={`url(#${glowId})`} />
      <ellipse cx="1476" cy="408" rx="18" ry="29" fill="#ffe7a5" filter={`url(#${glowId})`} />

      {/* Núcleo claro e definido, como no print de referência. */}
      <ellipse cx="829" cy="450" rx="16" ry="17" fill="#fff4ce" opacity=".88" />
      <ellipse cx="1476" cy="408" rx="8" ry="14" fill="#fff4ce" opacity=".85" />
    </svg>
  );
}

/**
 * Tela de autenticação do SOS Trânsito.
 * onLogin: função async ({ identificador, senha, lembrar }) => Promise<void>.
 * O login real e as permissões dos perfis devem ser validados na API.
 */
export default function LoginPage({ onLogin }) {
  const [identificador, setIdentificador] = useState("");
  const [senha, setSenha] = useState("");
  const [lembrar, setLembrar] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [carroAnimado, setCarroAnimado] = useState(false);
  const [carroCarregado, setCarroCarregado] = useState(false);
  const [repeticao, setRepeticao] = useState(0);
  const [farois, setFarois] = useState(true);
  const [mensagem, setMensagem] = useState("");
  const [enviando, setEnviando] = useState(false);

  async function enviar(event) {
    event.preventDefault();
    setMensagem("");
    if (!identificador.trim() || !senha) {
      setMensagem("Informe seu e-mail ou CPF e sua senha para continuar.");
      return;
    }
    if (typeof onLogin !== "function") {
      setMensagem("Interface pronta. Conecte a função onLogin à API para autenticar.");
      return;
    }
    try {
      setEnviando(true);
      await onLogin({ identificador: identificador.trim(), senha, lembrar });
    } catch (erro) {
      setMensagem(erro?.message || "Não foi possível entrar. Tente novamente.");
    } finally {
      setEnviando(false);
    }
  }

  function redesenhar() {
    setRepeticao((atual) => atual + 1);
    setCarroAnimado(true);
  }

  return (
    <main className="ignicao-login">
      <div className="ignicao-container">
        <section className="ignicao-hero" aria-label="Apresentação SOS Trânsito">
          <div className="ignicao-eyebrow">
            <span className="ignicao-eyebrow-line" aria-hidden="true" />
            SEU PRÓXIMO DESTINO COMEÇA AQUI
          </div>

          <div className="ignicao-heading-group">
            <h1 className="ignicao-heading">
              <span className="ignicao-heading-thin">SUA JORNADA</span>
              <span className="ignicao-heading-bold">CONTINUA.</span>
            </h1>
            <p className="ignicao-intro">
              Para cada imprevisto, um novo caminho.<br />
              Conte com a gente para seguir em frente.
            </p>
          </div>

          <div
            className={`ignicao-car-stage ${carroAnimado ? "is-moving" : ""} ${farois ? "lights-on" : ""}`}
            aria-label="Ilustração de carro esportivo branco"
          >
            <div className="ignicao-car-shadow" aria-hidden="true" />
            <div
              key={repeticao}
              className={`ignicao-car-visual ${repeticao > 0 ? "is-redrawing" : ""}`}
            >
              <img
                className="ignicao-car"
                src="/carro-sem-fundo.png"
                alt="Ilustração em traço preto e branco de um carro esportivo"
                draggable="false"
                onLoad={() => setCarroCarregado(true)}
              />
              {carroCarregado && <CarHeadlights />}
            </div>
          </div>

          <footer className="ignicao-hero-bottom">
            <span className="ignicao-footer-label"><i aria-hidden="true" /> PAIXÃO EM CADA TRAÇO.</span>
            <div className="ignicao-visual-controls" aria-label="Controles do carro">
              <button type="button" className="ignicao-replay" onClick={redesenhar} aria-label="Reiniciar animação" title="Reiniciar animação">
                <Icon name="replay" size={15} />
              </button>
              <button type="button" className={`ignicao-round-btn ${farois ? "is-active" : ""}`} onClick={() => setFarois((valor) => !valor)} aria-label={farois ? "Desligar faróis" : "Acender faróis"} aria-pressed={farois} title="Alternar faróis">
                <Icon name="headlight" size={17} />
              </button>
              <button type="button" className="ignicao-round-btn" onClick={() => setCarroAnimado((valor) => !valor)} aria-label={carroAnimado ? "Pausar animação" : "Iniciar animação"} aria-pressed={carroAnimado} title={carroAnimado ? "Pausar animação" : "Iniciar animação"}>
                <Icon name={carroAnimado ? "pause" : "play"} size={16} />
              </button>
            </div>
          </footer>
        </section>

        <div className="ignicao-divider" aria-hidden="true" />

        <section className="ignicao-access" aria-label="Acessar minha conta">
          <div className="ignicao-form-panel">
            <div className="ignicao-form-eyebrow"><span aria-hidden="true">●</span> CONECTE-SE AO SEU CAMINHO</div>
            <h2>Bom ter você<br />de volta.</h2>

            <form className="ignicao-form" onSubmit={enviar} noValidate>
              <div className="ignicao-field">
                <label htmlFor="ignicao-user">USUÁRIO</label>
                <div className="ignicao-input-wrap">
                  <Icon name="user" size={17} />
                  <input
                    id="ignicao-user"
                    type="text"
                    value={identificador}
                    onChange={(e) => { setIdentificador(e.target.value); setMensagem(""); }}
                    placeholder="Seu e-mail ou CPF"
                    autoComplete="username"
                    required
                  />
                </div>
              </div>
              <div className="ignicao-field">
                <label htmlFor="ignicao-password">SENHA</label>
                <div className="ignicao-input-wrap">
                  <Icon name="lock" size={17} />
                  <input
                    id="ignicao-password"
                    type={mostrarSenha ? "text" : "password"}
                    value={senha}
                    onChange={(e) => { setSenha(e.target.value); setMensagem(""); }}
                    placeholder="Sua senha"
                    autoComplete="current-password"
                    required
                  />
                  <button className="ignicao-eye-button" type="button" onClick={() => setMostrarSenha((valor) => !valor)} aria-label={mostrarSenha ? "Ocultar senha" : "Mostrar senha"}>
                    <Icon name={mostrarSenha ? "eye" : "eyeOff"} size={17} />
                  </button>
                </div>
              </div>

              <div className="ignicao-form-options">
                <label className="ignicao-remember" htmlFor="ignicao-remember">
                  <input id="ignicao-remember" type="checkbox" checked={lembrar} onChange={(e) => setLembrar(e.target.checked)} />
                  <span>Lembrar de mim</span>
                </label>
                <a href="/forgot-password">Esqueci minha senha</a>
              </div>

              {mensagem && <p className="ignicao-notice" role="alert">{mensagem}</p>}

              <button className="ignicao-login-btn" type="submit" disabled={enviando}>
                <span>{enviando ? "ENTRANDO..." : "ENTRAR NA MINHA CONTA"}</span>
                <Icon name="arrow" size={19} />
              </button>
            </form>

            <div className="ignicao-signup">Ainda não faz parte? <a href="/register">Crie sua conta <span aria-hidden="true">↗</span></a></div>
            <div className="ignicao-small-divider" />
            <div className="ignicao-form-footer"><Icon name="shield" size={14} /></div>
          </div>
        </section>
      </div>
      <span className="ignicao-decor ignicao-decor-left" aria-hidden="true">+</span>
      <span className="ignicao-decor ignicao-decor-right" aria-hidden="true">+</span>
    </main>
  );
}
