import LoginPage from "./pages/LoginPage.jsx";

export default function App() {
  // Para ativar o login real, passe onLogin={suaFuncaoDeLogin} ao componente.
  return <LoginPage />;
}
